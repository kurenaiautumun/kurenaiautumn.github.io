import React from 'react'
import BlogComp from '../BlogComponent/BlogComp'

function BlogEdit() {
    return (
        <div>
            <BlogComp />
        </div>
    )
}

export default BlogEdit