import React from 'react'

function NewElem(tag){
    let new_tag = tag['tag']
    console.log("tag1 = ", new_tag)
    let elem = document.createElement('p')
    return (
        <div>
            elem
        </div>)
}

export default NewElem